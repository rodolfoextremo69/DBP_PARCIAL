package com.ejemplo.cinebox;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Punto de entrada. Mantener esta clase en el paquete raiz permite component scanning. */
@SpringBootApplication
public class CineboxApplication {
    public static void main(String[] args) {
        SpringApplication.run(CineboxApplication.class, args);
    }
}
