package com.ejemplo.cinebox.repository;
import com.ejemplo.cinebox.entity.Pelicula;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface PeliculaRepository extends JpaRepository<Pelicula, Long>, JpaSpecificationExecutor<Pelicula> {
    boolean existsByCodigoCatalogoIgnoreCase(String codigoCatalogo);
    boolean existsByCodigoCatalogoIgnoreCaseAndIdNot(String codigoCatalogo, Long id);
    boolean existsByGenero_Id(Long generoId);
}
