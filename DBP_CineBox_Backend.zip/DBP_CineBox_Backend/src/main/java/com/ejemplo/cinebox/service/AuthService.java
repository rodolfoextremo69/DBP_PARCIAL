package com.ejemplo.cinebox.service;

import com.ejemplo.cinebox.dto.*;
import com.ejemplo.cinebox.entity.*;
import com.ejemplo.cinebox.exception.ConflictException;
import com.ejemplo.cinebox.repository.AccountRepository;
import com.ejemplo.cinebox.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Locale;

@Service @RequiredArgsConstructor
public class AuthService {
    private final AccountRepository accounts;
    private final PasswordEncoder encoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    @Transactional
    public AccountResponse registrar(RegisterRequest request) {
        String email = request.getEmail().trim().toLowerCase(Locale.ROOT);
        if (accounts.existsByEmailIgnoreCase(email)) throw new ConflictException("El email ya existe");
        Account account = new Account();
        account.setNombre(request.getNombre().trim());
        account.setEmail(email);
        account.setPassword(encoder.encode(request.getPassword()));
        account.setRole(Role.USER);   // PROHIBIDO permitir al cliente seleccionar ADMIN.
        Account saved = accounts.save(account);
        return new AccountResponse(saved.getId(), saved.getNombre(), saved.getEmail(), saved.getRole());
    }
    public AuthResponse login(LoginRequest request) {
        Authentication auth = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getEmail().trim(), request.getPassword()));
        Account account = (Account) auth.getPrincipal();
        return new AuthResponse(jwtService.generateToken(account), "Bearer",
            jwtService.getExpirationMillis()/1000, account.getRole());
    }
}
