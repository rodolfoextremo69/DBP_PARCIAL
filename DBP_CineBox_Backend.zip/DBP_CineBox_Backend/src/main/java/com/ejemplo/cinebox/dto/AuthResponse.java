package com.ejemplo.cinebox.dto;
import com.ejemplo.cinebox.entity.Role;
import lombok.AllArgsConstructor;
import lombok.Getter;
@Getter @AllArgsConstructor
public class AuthResponse {
    private String accessToken;
    private String tokenType;
    private Long expiresInSeconds;
    private Role role;
}
