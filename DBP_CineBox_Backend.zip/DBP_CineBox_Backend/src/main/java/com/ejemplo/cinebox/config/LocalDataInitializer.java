package com.ejemplo.cinebox.config;

import com.ejemplo.cinebox.entity.*;
import com.ejemplo.cinebox.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Locale;

/** SOLO PERFIL local. Usuarios/clave y peliculas de practica, nunca para produccion. */
@Configuration @Profile("local")
public class LocalDataInitializer {
    @Bean
    CommandLineRunner demoData(GeneroRepository generos, PeliculaRepository peliculas,
                               AccountRepository accounts, PasswordEncoder encoder,
                               @Value("${app.demo.admin-email}") String adminEmail,
                               @Value("${app.demo.admin-password}") String adminPassword) {
        return args -> {
            Genero cienciaFiccion = genero(generos, "Ciencia ficcion");
            genero(generos, "Comedia");
            genero(generos, "Drama");
            String normalizedEmail = adminEmail.trim().toLowerCase(Locale.ROOT);
            if (!accounts.existsByEmailIgnoreCase(normalizedEmail)) {
                Account admin = new Account();
                admin.setNombre("Administrador local");
                admin.setEmail(normalizedEmail);
                admin.setPassword(encoder.encode(adminPassword));
                admin.setRole(Role.ADMIN);
                accounts.save(admin);
            }
            if (!peliculas.existsByCodigoCatalogoIgnoreCase("FILM-001")) {
                Pelicula ejemplo = new Pelicula();
                ejemplo.setTitulo("Interestelar");
                ejemplo.setDirector("Christopher Nolan");
                ejemplo.setFechaEstreno(LocalDate.of(2014, 11, 7));
                ejemplo.setPrecio(new BigDecimal("39.90"));
                ejemplo.setStock(12);
                ejemplo.setCodigoCatalogo("FILM-001");
                ejemplo.setSinopsis("Película de ejemplo para practicar el backend.");
                ejemplo.setGenero(cienciaFiccion);
                peliculas.save(ejemplo);
            }
        };
    }
    private Genero genero(GeneroRepository repository, String nombre) {
        return repository.findByNombreIgnoreCase(nombre).orElseGet(() -> {
            Genero nuevo = new Genero();
            nuevo.setNombre(nombre);
            return repository.save(nuevo);
        });
    }
}
