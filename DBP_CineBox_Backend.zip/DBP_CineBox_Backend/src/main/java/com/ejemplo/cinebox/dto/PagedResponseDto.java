package com.ejemplo.cinebox.dto;
import lombok.Getter;
import org.springframework.data.domain.Page;
import java.util.List;

/** Evita devolver toda la metadata extensa de Page a los clientes. */
@Getter
public class PagedResponseDto<T> {
    private final List<T> content;
    private final int page;
    private final int size;
    private final long totalElements;
    private final int totalPages;
    private final boolean last;

    public PagedResponseDto(Page<T> pageResult) {
        this.content = pageResult.getContent();
        this.page = pageResult.getNumber();
        this.size = pageResult.getSize();
        this.totalElements = pageResult.getTotalElements();
        this.totalPages = pageResult.getTotalPages();
        this.last = pageResult.isLast();
    }
}
