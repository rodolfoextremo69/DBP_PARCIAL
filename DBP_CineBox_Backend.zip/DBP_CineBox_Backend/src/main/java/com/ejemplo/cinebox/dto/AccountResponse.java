package com.ejemplo.cinebox.dto;
import com.ejemplo.cinebox.entity.Role;
import lombok.AllArgsConstructor;
import lombok.Getter;
@Getter @AllArgsConstructor
public class AccountResponse {
    private Long id;
    private String nombre;
    private String email;
    private Role role;
    // NUNCA se devuelve password.
}
