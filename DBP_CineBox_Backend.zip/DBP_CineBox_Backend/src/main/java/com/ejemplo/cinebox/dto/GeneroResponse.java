package com.ejemplo.cinebox.dto;
import lombok.Getter;
import lombok.Setter;
@Getter @Setter
public class GeneroResponse {
    private Long id;
    private String nombre;
}
