package com.ejemplo.cinebox.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;

/** Tabla peliculas: muchos registros pueden apuntar al mismo genero. */
@Entity
@Table(name = "peliculas", uniqueConstraints = @UniqueConstraint(name = "uk_pelicula_codigo", columnNames = "codigo_catalogo"))
@Getter @Setter @NoArgsConstructor
public class Pelicula {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 160)
    private String titulo;
    @Column(nullable = false, length = 120)
    private String director;
    @Column(name = "fecha_estreno", nullable = false)
    private LocalDate fechaEstreno;
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal precio;
    @Column(nullable = false)
    private Integer stock;
    @Column(name = "codigo_catalogo", nullable = false, length = 20, unique = true)
    private String codigoCatalogo;
    @Column(length = 500)
    private String sinopsis;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "genero_id", nullable = false)
    private Genero genero;
}
