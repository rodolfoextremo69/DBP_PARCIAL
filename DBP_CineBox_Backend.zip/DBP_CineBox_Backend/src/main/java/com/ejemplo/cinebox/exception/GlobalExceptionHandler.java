package com.ejemplo.cinebox.exception;

import com.ejemplo.cinebox.dto.ApiError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiError> validation(MethodArgumentNotValidException e) {
        Map<String,String> campos = new LinkedHashMap<>();
        e.getBindingResult().getFieldErrors().forEach(f ->
            campos.putIfAbsent(f.getField(), f.getDefaultMessage()));
        return error(HttpStatus.BAD_REQUEST, "Datos invalidos", campos);
    }
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiError> jsonInvalido(HttpMessageNotReadableException e) {
        return error(HttpStatus.BAD_REQUEST, "JSON mal formado o tipo de dato incorrecto", Map.of());
    }
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiError> notFound(ResourceNotFoundException e) {
        return error(HttpStatus.NOT_FOUND, e.getMessage(), Map.of());
    }
    @ExceptionHandler(ConflictException.class)
    public ResponseEntity<ApiError> conflicto(ConflictException e) {
        return error(HttpStatus.CONFLICT, e.getMessage(), Map.of());
    }
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ApiError> restriccion(DataIntegrityViolationException e) {
        return error(HttpStatus.CONFLICT, "La operacion viola una restriccion de la BD", Map.of());
    }
    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<ApiError> credenciales(AuthenticationException e) {
        return error(HttpStatus.UNAUTHORIZED, "Credenciales invalidas", Map.of());
    }
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiError> permiso(AccessDeniedException e) {
        return error(HttpStatus.FORBIDDEN, "No tienes permisos", Map.of());
    }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiError> inesperado(Exception e) {
        log.error("Error inesperado", e);
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno", Map.of());
    }
    private ResponseEntity<ApiError> error(HttpStatus status, String message, Map<String,String> details) {
        return ResponseEntity.status(status).body(new ApiError(
            status.value(), status.getReasonPhrase(), message, Instant.now(), details));
    }
}
