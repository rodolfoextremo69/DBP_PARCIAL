package com.ejemplo.cinebox.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import javax.crypto.SecretKey;
import java.util.Date;

/** Emite y verifica tokens HMAC firmados. NO codifica contrasenas; eso lo hace BCrypt. */
@Service
public class JwtService {
    private final SecretKey signingKey;
    private final long expirationMillis;

    public JwtService(@Value("${jwt.secret}") String base64Secret,
                      @Value("${jwt.expiration-access}") long expirationMillis) {
        this.signingKey = Keys.hmacShaKeyFor(Decoders.BASE64.decode(base64Secret));
        if (expirationMillis <= 0) throw new IllegalArgumentException("La expiracion JWT debe ser positiva");
        this.expirationMillis = expirationMillis;
    }
    public long getExpirationMillis() { return expirationMillis; }

    public String generateToken(UserDetails user) {
        Date now = new Date();
        return Jwts.builder()
            .subject(user.getUsername())
            .claim("roles", user.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList())
            .issuedAt(now)
            .expiration(new Date(now.getTime() + expirationMillis))
            .signWith(signingKey)
            .compact();
    }
    /** parseSignedClaims verifica firma Y vencimiento; lanza JwtException si falla. */
    public String extractUsername(String token) {
        Claims claims = Jwts.parser().verifyWith(signingKey).build()
            .parseSignedClaims(token).getPayload();
        return claims.getSubject();
    }
    public boolean isTokenValid(String token, UserDetails user) {
        return extractUsername(token).equalsIgnoreCase(user.getUsername()) && user.isEnabled();
    }
}
