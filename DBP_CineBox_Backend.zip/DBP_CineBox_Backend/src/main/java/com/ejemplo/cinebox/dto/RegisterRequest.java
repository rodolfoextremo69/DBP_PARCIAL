package com.ejemplo.cinebox.dto;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
@Getter @Setter
public class RegisterRequest {
    @NotBlank @Size(min = 2, max = 100)
    private String nombre;
    @NotBlank @Email @Size(max = 180)
    private String email;
    @NotBlank @Size(min = 8, max = 72)
    private String password;
    // No se recibe role: un visitante no puede registrarse como ADMIN.
}
