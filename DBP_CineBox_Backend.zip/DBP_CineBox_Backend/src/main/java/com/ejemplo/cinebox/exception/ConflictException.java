package com.ejemplo.cinebox.exception;
public class ConflictException extends RuntimeException {
    public ConflictException(String message) { super(message); }
}
