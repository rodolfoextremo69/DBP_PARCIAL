package com.ejemplo.cinebox.dto;
import java.time.Instant;
import java.util.Map;
/** Respuesta coherente ante errores de validacion o reglas de negocio. */
public record ApiError(int status, String error, String message,
                       Instant timestamp, Map<String, String> details) {}
