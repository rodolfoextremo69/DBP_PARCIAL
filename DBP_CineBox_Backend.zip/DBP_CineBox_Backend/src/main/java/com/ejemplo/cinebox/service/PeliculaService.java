package com.ejemplo.cinebox.service;

import com.ejemplo.cinebox.dto.*;
import com.ejemplo.cinebox.entity.*;
import com.ejemplo.cinebox.exception.*;
import com.ejemplo.cinebox.repository.*;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import java.util.Locale;

/** La logica de negocio NO va en el Controller ni en el Repository. */
@Service
@RequiredArgsConstructor
public class PeliculaService {
    private final PeliculaRepository peliculas;
    private final GeneroRepository generos;
    private final ModelMapper mapper;

    @Transactional(readOnly = true)
    public Page<PeliculaResponse> listar(String titulo, Long generoId, Pageable pageable) {
        // Specification: crea el WHERE solamente con los filtros recibidos.
        Specification<Pelicula> filtro = (root, query, cb) -> cb.conjunction();
        if (StringUtils.hasText(titulo)) {
            String texto = "%" + titulo.trim().toLowerCase(Locale.ROOT) + "%";
            filtro = filtro.and((root, query, cb) -> cb.like(cb.lower(root.get("titulo")), texto));
        }
        if (generoId != null) {
            filtro = filtro.and((root, query, cb) -> cb.equal(root.get("genero").get("id"), generoId));
        }
        return peliculas.findAll(filtro, pageable).map(this::toResponse);
    }
    @Transactional(readOnly = true)
    public PeliculaResponse obtener(Long id) { return toResponse(buscarEntidad(id)); }

    @Transactional
    public PeliculaResponse crear(PeliculaRequest request) {
        if (peliculas.existsByCodigoCatalogoIgnoreCase(request.getCodigoCatalogo()))
            throw new ConflictException("Ya existe una pelicula con ese codigo");
        Genero genero = buscarGenero(request.getGeneroId());
        Pelicula entity = mapper.map(request, Pelicula.class);
        entity.setId(null);                   // El cliente no define el ID.
        entity.setGenero(genero);              // La FK se resuelve desde BD.
        return toResponse(peliculas.save(entity));
    }
    @Transactional
    public PeliculaResponse actualizar(Long id, PeliculaRequest request) {
        Pelicula entity = buscarEntidad(id);
        if (peliculas.existsByCodigoCatalogoIgnoreCaseAndIdNot(request.getCodigoCatalogo(), id))
            throw new ConflictException("El codigo pertenece a otra pelicula");
        Genero genero = buscarGenero(request.getGeneroId());
        // Actualizacion explicita: nunca sobreescribimos accidentalmente el ID.
        entity.setTitulo(request.getTitulo());
        entity.setDirector(request.getDirector());
        entity.setFechaEstreno(request.getFechaEstreno());
        entity.setPrecio(request.getPrecio());
        entity.setStock(request.getStock());
        entity.setCodigoCatalogo(request.getCodigoCatalogo());
        entity.setSinopsis(request.getSinopsis());
        entity.setGenero(genero);
        return toResponse(peliculas.save(entity));
    }
    @Transactional
    public void eliminar(Long id) { peliculas.delete(buscarEntidad(id)); }

    private Pelicula buscarEntidad(Long id) {
        return peliculas.findById(id).orElseThrow(() ->
            new ResourceNotFoundException("Pelicula no encontrada: " + id));
    }
    private Genero buscarGenero(Long id) {
        return generos.findById(id).orElseThrow(() ->
            new ResourceNotFoundException("Genero no encontrado: " + id));
    }
    private PeliculaResponse toResponse(Pelicula entity) {
        PeliculaResponse result = mapper.map(entity, PeliculaResponse.class);
        result.setGenero(mapper.map(entity.getGenero(), GeneroResponse.class));
        return result;
    }
}
