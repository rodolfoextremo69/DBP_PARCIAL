package com.ejemplo.cinebox.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.ArrayList;
import java.util.List;

/** Un genero puede tener muchas peliculas. No retornamos Entities directamente como JSON. */
@Entity
@Table(name = "generos", uniqueConstraints = @UniqueConstraint(name = "uk_genero_nombre", columnNames = "nombre"))
@Getter @Setter @NoArgsConstructor
public class Genero {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 70, unique = true)
    private String nombre;

    @OneToMany(mappedBy = "genero", fetch = FetchType.LAZY)
    private List<Pelicula> peliculas = new ArrayList<>();
}
