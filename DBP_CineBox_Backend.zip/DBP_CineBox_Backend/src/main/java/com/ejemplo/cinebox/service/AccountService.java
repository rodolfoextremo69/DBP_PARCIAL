package com.ejemplo.cinebox.service;
import com.ejemplo.cinebox.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.util.Locale;

/** Spring Security llama loadUserByUsername durante el login o la validacion de JWT. */
@Service @RequiredArgsConstructor
public class AccountService implements UserDetailsService {
    private final AccountRepository accounts;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return accounts.findByEmailIgnoreCase(username.trim().toLowerCase(Locale.ROOT))
            .orElseThrow(() -> new UsernameNotFoundException("Cuenta inexistente"));
    }
}
