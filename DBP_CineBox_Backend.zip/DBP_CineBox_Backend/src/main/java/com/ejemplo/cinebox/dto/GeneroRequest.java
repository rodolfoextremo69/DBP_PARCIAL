package com.ejemplo.cinebox.dto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
@Getter @Setter
public class GeneroRequest {
    @NotBlank(message = "El nombre del genero es obligatorio")
    @Size(min = 2, max = 70)
    private String nombre;
}
