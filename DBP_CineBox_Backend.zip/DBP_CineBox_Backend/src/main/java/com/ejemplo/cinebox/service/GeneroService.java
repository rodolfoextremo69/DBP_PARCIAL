package com.ejemplo.cinebox.service;

import com.ejemplo.cinebox.dto.*;
import com.ejemplo.cinebox.entity.Genero;
import com.ejemplo.cinebox.exception.*;
import com.ejemplo.cinebox.repository.*;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class GeneroService {
    private final GeneroRepository generos;
    private final PeliculaRepository peliculas;
    private final ModelMapper mapper;

    @Transactional(readOnly = true)
    public List<GeneroResponse> listar() {
        return generos.findAll().stream().map(g -> mapper.map(g, GeneroResponse.class)).toList();
    }
    @Transactional(readOnly = true)
    public GeneroResponse obtener(Long id) {
        return mapper.map(buscarEntidad(id), GeneroResponse.class);
    }
    @Transactional
    public GeneroResponse crear(GeneroRequest request) {
        String nombre = request.getNombre().trim();
        if (generos.existsByNombreIgnoreCase(nombre)) throw new ConflictException("El genero ya existe");
        Genero entity = mapper.map(request, Genero.class);
        entity.setId(null);
        entity.setNombre(nombre);
        return mapper.map(generos.save(entity), GeneroResponse.class);
    }
    @Transactional
    public GeneroResponse actualizar(Long id, GeneroRequest request) {
        Genero entity = buscarEntidad(id);
        String nombre = request.getNombre().trim();
        if (generos.existsByNombreIgnoreCaseAndIdNot(nombre, id))
            throw new ConflictException("Ya existe otro genero con este nombre");
        entity.setNombre(nombre);
        return mapper.map(generos.save(entity), GeneroResponse.class);
    }
    @Transactional
    public void eliminar(Long id) {
        Genero entity = buscarEntidad(id);
        if (peliculas.existsByGenero_Id(id))
            throw new ConflictException("No se puede eliminar un genero que tiene peliculas");
        generos.delete(entity);
    }
    private Genero buscarEntidad(Long id) {
        return generos.findById(id).orElseThrow(() ->
            new ResourceNotFoundException("Genero no encontrado: " + id));
    }
}
