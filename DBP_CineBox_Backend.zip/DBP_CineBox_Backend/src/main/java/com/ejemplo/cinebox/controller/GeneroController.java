package com.ejemplo.cinebox.controller;
import com.ejemplo.cinebox.dto.*;
import com.ejemplo.cinebox.service.GeneroService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/generos") @RequiredArgsConstructor
public class GeneroController {
    private final GeneroService service;
    @GetMapping
    public List<GeneroResponse> listar() { return service.listar(); }
    @GetMapping("/{id}")
    public GeneroResponse obtener(@PathVariable Long id) { return service.obtener(id); }
    @PostMapping @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<GeneroResponse> crear(@Valid @RequestBody GeneroRequest dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.crear(dto));
    }
    @PutMapping("/{id}") @PreAuthorize("hasRole('ADMIN')")
    public GeneroResponse actualizar(@PathVariable Long id, @Valid @RequestBody GeneroRequest dto) {
        return service.actualizar(id, dto);
    }
    @DeleteMapping("/{id}") @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
