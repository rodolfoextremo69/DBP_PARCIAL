package com.ejemplo.cinebox.dto;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;

/** El cliente manda generoId, no una Entity Genero completa. */
@Getter @Setter
public class PeliculaRequest {
    @NotBlank(message = "El titulo es obligatorio")
    @Size(min = 2, max = 160)
    private String titulo;

    @NotBlank(message = "El director es obligatorio")
    @Size(max = 120)
    private String director;

    @NotNull(message = "Indica la fecha de estreno")
    @PastOrPresent(message = "La fecha no puede estar en el futuro")
    private LocalDate fechaEstreno;

    @NotNull(message = "El precio es obligatorio")
    @DecimalMin(value = "0.01", message = "El precio debe ser mayor que cero")
    private BigDecimal precio;

    @NotNull(message = "El stock es obligatorio")
    @Min(value = 0, message = "El stock no puede ser negativo")
    private Integer stock;

    @NotBlank
    @Pattern(regexp = "^[A-Z0-9-]{4,20}$", message = "Usa 4-20 caracteres: A-Z, 0-9 o guion")
    private String codigoCatalogo;

    @Size(max = 500)
    private String sinopsis;

    @NotNull(message = "El id del genero es obligatorio")
    private Long generoId;
}
