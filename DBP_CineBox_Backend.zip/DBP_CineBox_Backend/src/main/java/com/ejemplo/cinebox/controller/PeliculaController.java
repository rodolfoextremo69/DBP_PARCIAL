package com.ejemplo.cinebox.controller;
import com.ejemplo.cinebox.dto.*;
import com.ejemplo.cinebox.service.PeliculaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/peliculas") @RequiredArgsConstructor
public class PeliculaController {
    private final PeliculaService service;

    /** /api/peliculas?titulo=inter&generoId=1&page=0&size=5&sort=precio,desc */
    @GetMapping
    public PagedResponseDto<PeliculaResponse> listar(
        @RequestParam(required = false) String titulo,
        @RequestParam(required = false) Long generoId,
        @PageableDefault(size = 10, sort = "id", direction = Sort.Direction.ASC) Pageable pageable) {
        return new PagedResponseDto<>(service.listar(titulo, generoId, pageable));
    }
    @GetMapping("/{id}")
    public PeliculaResponse obtener(@PathVariable Long id) { return service.obtener(id); }

    @PostMapping @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PeliculaResponse> crear(@Valid @RequestBody PeliculaRequest dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.crear(dto));
    }
    @PutMapping("/{id}") @PreAuthorize("hasRole('ADMIN')")
    public PeliculaResponse actualizar(@PathVariable Long id, @Valid @RequestBody PeliculaRequest dto) {
        return service.actualizar(id, dto);
    }
    @DeleteMapping("/{id}") @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
