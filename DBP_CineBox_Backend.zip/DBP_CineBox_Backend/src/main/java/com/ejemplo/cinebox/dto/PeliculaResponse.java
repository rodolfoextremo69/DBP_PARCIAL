package com.ejemplo.cinebox.dto;
import lombok.Getter;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;

@Getter @Setter
public class PeliculaResponse {
    private Long id;
    private String titulo;
    private String director;
    private LocalDate fechaEstreno;
    private BigDecimal precio;
    private Integer stock;
    private String codigoCatalogo;
    private String sinopsis;
    private GeneroResponse genero;
}
