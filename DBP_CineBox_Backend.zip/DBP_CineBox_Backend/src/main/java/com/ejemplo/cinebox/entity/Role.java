package com.ejemplo.cinebox.entity;
/** El cliente que se registra siempre recibe USER; no puede elegir ADMIN. */
public enum Role { USER, ADMIN }
