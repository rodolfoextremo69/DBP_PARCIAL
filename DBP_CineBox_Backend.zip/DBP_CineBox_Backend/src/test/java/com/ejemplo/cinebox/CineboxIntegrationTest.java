package com.ejemplo.cinebox;

import com.ejemplo.cinebox.entity.*;
import com.ejemplo.cinebox.repository.*;
import com.ejemplo.cinebox.security.JwtService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class CineboxIntegrationTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @Autowired GeneroRepository generos;
    @Autowired PeliculaRepository peliculas;
    @Autowired AccountRepository accounts;
    @Autowired PasswordEncoder encoder;
    @Autowired JwtService jwtService;

    private Long generoId;
    @BeforeEach
    void preparar() {
        peliculas.deleteAll();
        generos.deleteAll();
        accounts.deleteAll();
        Genero genero = new Genero();
        genero.setNombre("Drama");
        generoId = generos.save(genero).getId();
    }
    private String token(Role role) {
        Account a = new Account();
        a.setEmail(UUID.randomUUID() + "@cinebox.test");
        a.setNombre("Usuario de prueba");
        a.setPassword(encoder.encode("Clave12345!"));
        a.setRole(role);
        return jwtService.generateToken(accounts.save(a));
    }
    private String peliculaJson(String titulo, String codigo) {
        return """
            {"titulo":"%s", "director":"Directora Prueba", "fechaEstreno":"2020-05-10",
             "precio":25.90, "stock":10, "codigoCatalogo":"%s",
             "sinopsis":"Un ejemplo educativo", "generoId":%d}
            """.formatted(titulo, codigo, generoId);
    }
    @Test
    void accesoSinJwtDevuelve401() throws Exception {
        mvc.perform(get("/api/peliculas")).andExpect(status().isUnauthorized());
    }
    @Test
    void registroNoPermiteElegirAdministradorYLoginGeneraJwt() throws Exception {
        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content(""" 
                    {"nombre":"Ana", "email":"ANA@MAIL.COM", "password":"Clave12345!", "role":"ADMIN"}
                    """))
            .andExpect(status().isBadRequest()); // JSON extra: propiedad role esta prohibida.

        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content("""
                    {"nombre":"Ana", "email":"ANA@MAIL.COM", "password":"Clave12345!"}
                    """))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.role").value("USER"))
            .andExpect(jsonPath("$.password").doesNotExist());

        Account saved = accounts.findByEmailIgnoreCase("ana@mail.com").orElseThrow();
        assertTrue(encoder.matches("Clave12345!", saved.getPassword()));
        String response = mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                .content("""
                    {"email":"ana@mail.com", "password":"Clave12345!"}
                    """))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.tokenType").value("Bearer"))
            .andReturn().getResponse().getContentAsString();
        JsonNode result = json.readTree(response);
        mvc.perform(get("/api/generos").header("Authorization", "Bearer " + result.get("accessToken").asText()))
            .andExpect(status().isOk());
    }
    @Test
    void usuarioPuedeLeerPeroNoCrearYAdminSiPuede() throws Exception {
        String user = token(Role.USER);
        String admin = token(Role.ADMIN);
        String body = peliculaJson("Pelicula A", "MOV-100");
        mvc.perform(post("/api/peliculas").header("Authorization", "Bearer " + user)
                .contentType(MediaType.APPLICATION_JSON).content(body))
            .andExpect(status().isForbidden());
        mvc.perform(post("/api/peliculas").header("Authorization", "Bearer " + admin)
                .contentType(MediaType.APPLICATION_JSON).content(body))
            .andExpect(status().isCreated()).andExpect(jsonPath("$.genero.nombre").value("Drama"));
        mvc.perform(get("/api/peliculas?page=0&size=5&titulo=Pelicula")
                .header("Authorization", "Bearer " + user))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.totalElements").value(1))
            .andExpect(jsonPath("$.content[0].codigoCatalogo").value("MOV-100"));
    }
    @Test
    void validarDtoDuplicadosYNoEliminarGeneroConPeliculas() throws Exception {
        String admin = token(Role.ADMIN);
        mvc.perform(post("/api/peliculas").header("Authorization", "Bearer " + admin)
                .contentType(MediaType.APPLICATION_JSON).content(peliculaJson("", "MOV-101")))
            .andExpect(status().isBadRequest()).andExpect(jsonPath("$.details.titulo").exists());
        String body = peliculaJson("Pelicula B", "MOV-102");
        mvc.perform(post("/api/peliculas").header("Authorization", "Bearer " + admin)
                .contentType(MediaType.APPLICATION_JSON).content(body)).andExpect(status().isCreated());
        mvc.perform(post("/api/peliculas").header("Authorization", "Bearer " + admin)
                .contentType(MediaType.APPLICATION_JSON).content(body)).andExpect(status().isConflict());
        mvc.perform(delete("/api/generos/" + generoId)
                .header("Authorization", "Bearer " + admin)).andExpect(status().isConflict());
    }
    @Test
    void contrasenaIncorrectaOJwtInvalidoDevuelven401() throws Exception {
        mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                .content("""
                    {"email":"nadie@mail.com", "password":"incorrecta"}
                    """))
            .andExpect(status().isUnauthorized());
        mvc.perform(get("/api/peliculas").header("Authorization", "Bearer falso.jwt.token"))
            .andExpect(status().isUnauthorized());
    }
}
