-- Puedes ejecutar esto desde psql / pgAdmin luego de iniciar Spring Boot.
SELECT id, nombre FROM generos ORDER BY id;
SELECT p.id, p.titulo, p.codigo_catalogo, p.precio, p.stock, g.nombre AS genero
FROM peliculas p JOIN generos g ON g.id=p.genero_id ORDER BY p.id;
SELECT id, nombre, email, role FROM accounts ORDER BY id;
-- Nunca muestres ni exportes hashes de password en capturas de pantalla.
